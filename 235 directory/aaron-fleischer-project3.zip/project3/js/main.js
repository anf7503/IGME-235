"use strict";
const app = new PIXI.Application({
    width: 800,
    height: 600
});

document.body.appendChild(app.view);



// constants
const sceneWidth = app.view.width;
const sceneHeight = app.view.height;

// pre-load the images
app.loader.
    add([
        "images/spaceship.png",
        "images/explosions.png"
    ]);
app.loader.onComplete.add(setup);
app.loader.load();

// aliases
let stage;

// game variables
let startScene;
let howToPlayScene;
let levelScene, levelLabel;
let gameScene,ship,scoreLabel,lifeLabel,shootSound,hitSound,fireballSound;
let gameOverScene;

let enemies = [];
let bullets = [];
let enemyBullets = [];
let invincible = false;
let aliens = [];
let explosions = [];
let explosionTextures;
let score = 0;
let life = 2;
let lastShotFired;
let lastEnemyShotFired;
let lastHit;
let currentTime;
let levelNum = 0;
let paused = true;
let gameOverScoreLabel;
let keys = {};

// From Professor Chin's Pixi.js tutorial video
// Pixi.js: Sprite Keyboard Movement
window.addEventListener("keydown", keysDown);
window.addEventListener("keyup", keysUp);

function keysDown(e) {
    console.log(e.keyCode);
    keys[e.keyCode] = true;
}

function keysUp(e) {
    console.log(e.keyCode);
    keys[e.keyCode] = false;
}


// game setup functions

function increaseScoreBy(value){
    score += value;
    // gain a life every 20 enemies killed
    if (score % 20 == 0) {
        decreaseLifeBy(-1);
    }
    scoreLabel.text = `Score  ${score}`;
}

function decreaseLifeBy(value){
    life -= value;
    life = parseInt(life);
    lifeLabel.text = `Life     ${life}`;
}

function createEnemies(enemiesPerRow) {
    for (let i=0; i < 4; i++)
    {
        for (let j=1; j <= enemiesPerRow; j++)
        {
            if (levelNum > 5) {
                let n = new Enemy((5*5));
                n.x = ((sceneWidth)/enemiesPerRow) * (j-.5);
                n.y = (sceneHeight - 400) + 25 * i;
                enemies.push(n);
                gameScene.addChild(n);
            }
            else {
                let n = new Enemy((5*levelNum));
                n.x = ((sceneWidth)/enemiesPerRow) * (j-.5);
                n.y = (sceneHeight - 400) + 25 * i;
                enemies.push(n);
                gameScene.addChild(n);
            }
        }
    }
}

// bullet management

function fireBullet() {
    if (paused) return;
    
    let b = new Bullet(0xFFFFFF, ship.x, ship.y);
    bullets.push(b);
    gameScene.addChild(b);
    shootSound.play();    
}

function enemyBulletFire(enemyNumber) {
    if (paused) return;

    let enemy = Math.floor(Math.random() * enemyNumber);
    let b;
    if(levelNum > 5) b = new Bullet(0xFF0000, enemies[enemy].x, enemies[enemy].y, true, 150);
    else b = new Bullet(0xFF0000, enemies[enemy].x, enemies[enemy].y, true, 100);
    enemyBullets.push(b);
    gameScene.addChild(b);
    shootSound.play();
}

// explosions, may remove

function loadSpriteSheet() {
    // the 16 animation frames in each row are 64 x 64 pixels
    // we are using the second row
    // http://pixijs.download/release/docs/PIXI.BaseTexture.html
    let spriteSheet = PIXI.BaseTexture.from("images/explosions.png");
    let width = 64;
    let height = 64;
    let numFrames = 16;
    let textures = [];
    for (let i = 0; i < numFrames; i++)
    {
        // http://pixijs.download/release/docs/PIXI.Texture.html
        let frame = new PIXI.Texture(spriteSheet, new PIXI.Rectangle(i*width, 64, width, height));
        textures.push(frame);
    }
    return textures;
}

function createExplosion(x, y, frameWidth, frameHeight) {
    // http://pixijs.download/release/docs/PIXI.AnimatedSprite.html
    // the animation frames are 64 x 64 pixels
    let w2 = frameWidth / 2;
    let h2 = frameHeight / 2;
    let expl = new PIXI.AnimatedSprite(explosionTextures);
    expl.x = x - w2; // have the explosion appear at circle's center
    expl.y = y - h2; //  "    "     "        "    "    "        "
    expl.animationSpeed = 1 / 7;
    expl.loop = false;
    expl.onComplete = e => gameScene.removeChild(expl);
    explosions.push(expl);
    gameScene.addChild(expl);
    expl.play();
}

// helper function

function labelAndButtonMaker(label, x = 0, y = 0, size = 48, button = false, color = 0xFFFFFF) {
    label.x = x;
    label.y = y;

    if (button) {
        label.style = new PIXI.TextStyle({
            fill: color,
            fontSize: size,
            fontFamily: "Verdana",
            fontStyle: "italic"
        });
        label.interactive = true;
        label.buttonStyle = true;
    }

    else {
        label.style = new PIXI.TextStyle({
            fill: color,
            fontSize: size,
            fontFamily: "Verdana"
        });
    }
}

// set up scenes

function createLabelsAndButtons() {
    // set up 'startScene'

    // Title label
    let titleLabel = new PIXI.Text("Mr. Galaxy");
    labelAndButtonMaker(titleLabel, 85, 120, 120);
    startScene.addChild(titleLabel);

    // button that takes you to the how to play menu
    let htpButton = new PIXI.Text("How to play");
    labelAndButtonMaker(htpButton, 300, 350 , 32, true);
    htpButton.on("pointerup", htpMenu);
    htpButton.on("pointerover", e => e.target.alpha = 0.7);
    htpButton.on("pointerout", e => e.currentTarget.alpha = 1.0);
    startScene.addChild(htpButton);

    // start game button
    let startButton = new PIXI.Text("Press Space or click here to start");
    labelAndButtonMaker(startButton, 50, (sceneHeight - 100), 42, true);
    startButton.on("pointerup", startGame);
    startButton.on("pointerover", e => e.target.alpha = 0.7);
    startButton.on("pointerout", e => e.currentTarget.alpha = 1.0);
    startScene.addChild(startButton);

    // set up 'howToPlayScene'
    let movementLabel = new PIXI.Text("Use 'A' and 'D' keys or the left and right arrows\nto move the ship left and right");
    labelAndButtonMaker(movementLabel, 20, 50, 32);
    howToPlayScene.addChild(movementLabel);

    let shootLabel = new PIXI.Text("Use the Spacebar to shoot.\nThere is a 3 second delay between shots.");
    labelAndButtonMaker(shootLabel, 20, 200, 32);
    howToPlayScene.addChild(shootLabel);

    let loseConditionLabel = new PIXI.Text("If you run out of lives or an enemy makes\nit past you, it's game over!")
    labelAndButtonMaker(loseConditionLabel, 20, 350, 32);
    howToPlayScene.addChild(loseConditionLabel);

    let backButton = new PIXI.Text("Back");
    labelAndButtonMaker(backButton, (sceneWidth/2 - 70), (sceneHeight - 100), 48, true);
    backButton.on("pointerup", backToStart);
    backButton.on("pointerover", e => e.target.alpha = 0.7);
    backButton.on("pointerout", e => e.currentTarget.alpha = 1.0);
    howToPlayScene.addChild(backButton);

    // set up 'levelScene'
    levelLabel = new PIXI.Text();
    labelAndButtonMaker(levelLabel, 245, 150, 100);
    levelScene.addChild(levelLabel);

    let levelNextButton = new PIXI.Text("Press Space or click here to start");
    labelAndButtonMaker(levelNextButton, 50, (sceneHeight - 100), 42, true);
    levelNextButton.on("pointerup", enterGame);
    levelNextButton.on("pointerover", e => e.target.alpha = 0.7);
    levelNextButton.on("pointerout", e => e.currentTarget.alpha = 1.0);
    levelScene.addChild(levelNextButton);

    // set up 'gameScene'
    
    // life label
    lifeLabel = new PIXI.Text();
    labelAndButtonMaker(lifeLabel, 5, 26, 18);
    gameScene.addChild(lifeLabel);
    decreaseLifeBy(0);

    // score label
    scoreLabel = new PIXI.Text();
    labelAndButtonMaker(scoreLabel, 5, 5, 18);
    gameScene.addChild(scoreLabel);
    increaseScoreBy(0);


    // set up `gameOverScene`
    // game over text
    let gameOverText = new PIXI.Text("Game Over");
    labelAndButtonMaker(gameOverText, 100, (sceneHeight/2 - 160), 64);
    gameOverScene.addChild(gameOverText);

    // final score label
    gameOverScoreLabel = new PIXI.Text();
    labelAndButtonMaker(gameOverScoreLabel, 100, (sceneHeight - 160), 32);
    gameOverScene.addChild(gameOverScoreLabel);

    // "play again?" button
    let playAgainButton = new PIXI.Text("Play Again?");
    labelAndButtonMaker(playAgainButton, 150, (sceneHeight - 100), 48, true);
    playAgainButton.on("pointerup", startGame);
    playAgainButton.on('pointerover', e=>e.target.alpha = 0.7);
    playAgainButton.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    gameOverScene.addChild(playAgainButton);
}

// scene to scene functions

function htpMenu(){
    startScene.visible = false;
    howToPlayScene.visible = true;
}

function backToStart(){
    startScene.visible = true;
    howToPlayScene.visible = false;
    gameOverScene.visible = false;
    gameScene.visible = false;
    levelScene.visible = false;
}

function startGame(){
    paused = true;
    levelNum = 1;
    score = 0;
    life = 2;
    lastShotFired = new Date();
    lastEnemyShotFired = new Date();
    lastHit = new Date();
    currentTime = new Date();
    increaseScoreBy(0);
    decreaseLifeBy(0);
    createEnemies(8);
    ship.x = 300;
    levelLabel.text = `Belt  ${levelNum}`;
    startScene.visible = false;
    gameOverScene.visible = false;
    gameScene.visible = false;
    howToPlayScene.visible = false;
    levelScene.visible = true;
}

function enterGame(){
    paused = false;
    ship.x = 300;
    startScene.visible = false;
    gameOverScene.visible = false;
    gameScene.visible = true;
    howToPlayScene.visible = false;
    levelScene.visible = false;
}

function loadLevel() {
    paused = true;
    levelNum ++;
    if (levelNum > 10) createEnemies(10);
    levelLabel.text = `Belt  ${levelNum}`;
    startScene.visible = false;
    gameOverScene.visible = false;
    gameScene.visible = false;
    howToPlayScene.visible = false;
    levelScene.visible = true;
}

function end()
{
    paused = true;
    // clear out level
    enemies.forEach(c=>gameScene.removeChild(c));
    enemies = [];

    bullets.forEach(b=>gameScene.removeChild(b));
    bullets = [];

    explosions.forEach(e=>gameScene.removeChild(e));
    explosions = [];

    // set game over score label
    gameOverScoreLabel.text = `    Your final score is ${score}`;

    // show game over scene
    gameOverScene.visible = true;
    gameScene.visible = false;
}


// main gameloop

function gameLoop(){
	if (paused) return;
	
	// Calculate "delta time"
    let dt = 1/app.ticker.FPS;
    if (dt > 1/12) dt=1/12;

    // update the current time
    currentTime = new Date();

	// Move Ship
    // check for a, d, left, and right

    // keep the ship on screen with clamp()
    //let w2 = ship.width/2;
    //ship.x = clamp(ship.x, 0+w2, sceneWidth-w2);

    // keypresses

    // invincible check
    if (currentTime - lastHit >= 3) {
        invincible = false;
    }

    let moveDown = false;

    // enemy fires a bullet every 3 seconds
    // 3000 since its in milliseconds
    if (currentTime - lastEnemyShotFired >= 3000) {
        enemyBulletFire(enemies.length);
        lastEnemyShotFired = new Date();
    }
	
	// Move Enemies
	for (let n of enemies) 
    {
        n.move(dt);
        if (n.x <= n.width + 15 || n.x >= sceneWidth - 15)
        {
            moveDown = true;
        }
    }

    // moves down when the enemies hit the edge
    if (moveDown) {
        for (let n of enemies) 
        {
            n.reflectX();
            n.y += 10;
            n.move(dt);
        }
    }

    for (let n of enemies) 
    {
        // ends game if enemy makes it past the bottom
        if (n.y >= sceneHeight - 10)
        {
            end();
            return;
        }
    }
	
	// Move Bullets
	for (let b of bullets)
    {
		b.move(dt);
	}

    for (let b of enemyBullets)
    {
		b.move(dt);
	}

	// Check for Collisions
	for (let n of enemies)
    {
        for (let b of bullets)
        {
            // enemies & bullets
            if (rectsIntersect(n,b))
            {
                fireballSound.play();
                createExplosion(n.x, n.y, 64, 64);
                gameScene.removeChild(n);
                n.isAlive = false;
                gameScene.removeChild(b);
                b.isAlive = false;
                increaseScoreBy(1);
            }

            if (b.y < -10) b.isAlive = false;
        }
        // enemies & ships
        if (n.isAlive && !invincible && rectsIntersect(n,ship))
        {
            hitSound.play();
            gameScene.removeChild(n);
            n.isAlive = false;
            decreaseLifeBy(1);
            invincible = true;
            lastHit = new Date();
        }
    }

    // enemy bullet collision
    for (let b of enemyBullets)
    {
        if (b.isAlive && !invincible && rectsIntersect(b, ship))
        {
            hitSound.play();
            gameScene.removeChild(b);
            b.isAlive = false;
            decreaseLifeBy(1);
            invincible = true;
            lastHit = new Date();
        }

        if (b.y > (sceneHeight + 10)) b.isAlive = false;
    }

	// Clean up
	
    // Remove Dead Bullets
    bullets = bullets.filter(b=>b.isAlive);

    // Remove Dead enemies
    enemies = enemies.filter(n=>n.isAlive);

    // Remove Explosions
    explosions = explosions.filter(e=>e.playing);

    // keypresses
    // spacebar
    if (keys["32"])
    {
        if (currentTime - lastShotFired >= 2000) {
            fireBullet();
            lastShotFired = new Date();
        }
    }

    // left arrow
    if (keys["37"])
    {
        if (ship.x > (ship.width/2 + 2)) ship.x -= 2;
    }

    // right arrow
    if (keys["39"])
    {
        if (ship.x < (sceneWidth - ship.width/2 - 2)) ship.x += 2;
    }

    // 'A'
    if (keys["65"])
    {
        if (ship.x > (ship.width/2 + 2)) ship.x -= 2;
    }

    // 'D'
    if (keys["68"])
    {
        if (ship.x < (sceneWidth - ship.width/2 - 2)) ship.x += 2;
    }

	
	// game over (employment) check
	if (life <= 0)
    {
        end();
        return; // so we don't load a new level
    }
	
	// Load next level
    if (enemies.length == 0)
    {
        loadLevel();
    }

}

// the setup

function setup() {
	stage = app.stage;
	// create all of the scenes

    // start scene
	startScene = new PIXI.Container();
    stage.addChild(startScene);

	// #2 - Create the main `game` scene and make it invisible
    gameScene = new PIXI.Container();
    gameScene.visible = false;
    stage.addChild(gameScene);

	// #3 - Create the `gameOver` scene and make it invisible
	gameOverScene = new PIXI.Container();
    gameOverScene.visible = false;
    stage.addChild(gameOverScene);

    // scene that tells you which level you are on
    levelScene = new PIXI.Container();
    levelScene.visible = false;
    stage.addChild(levelScene);

	// How to play scene
	howToPlayScene = new PIXI.Container();
    howToPlayScene.visible = false;
    stage.addChild(howToPlayScene);

	// Create labels for all scenes
	createLabelsAndButtons();

	// Create ship
    ship = new Ship();
    gameScene.addChild(ship);

	// Load Sounds
    shootSound = new Howl({
        src: ['sounds/shoot.wav']
    });

    hitSound = new Howl({
        src: ['sounds/hit.mp3']
    });

    fireballSound = new Howl({
        src: ['sounds/fireball.mp3']
    });

	// Load sprite sheet
    explosionTextures = loadSpriteSheet();

		
	// Start update loop
    app.ticker.add(gameLoop);
}
